package com.example.m1virtual

import android.app.Activity
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.media.midi.MidiDevice
import android.media.midi.MidiDeviceInfo
import android.media.midi.MidiManager
import android.os.Bundle
import android.content.Context
import android.graphics.Color
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.PI
import kotlin.math.sin

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var midiManager: MidiManager
    private var midiDevice: MidiDevice? = null
    private var synth: SimpleSynth? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        synth = SimpleSynth().also { it.start() }
        midiManager = getSystemService(Context.MIDI_SERVICE) as MidiManager

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(24, 28, 24, 24)
            setBackgroundColor(Color.rgb(20, 24, 34))
        }
        val title = TextView(this).apply {
            text = "M1 VIRTUAL"
            textSize = 28f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        status = TextView(this).apply {
            text = "Motor de audio listo · MIDI sin conectar"
            textSize = 14f
            setTextColor(Color.rgb(180, 205, 220))
            gravity = Gravity.CENTER
            setPadding(8, 18, 8, 18)
        }
        val midi = Button(this).apply {
            text = "BUSCAR TECLADO MIDI USB"
            setOnClickListener { scanMidi() }
        }
        val note = Button(this).apply {
            text = "PROBAR SONIDO"
            setOnClickListener { synth?.noteOn(60, 110) }
            setOnLongClickListener { synth?.noteOff(60); true }
        }
        val info = TextView(this).apply {
            text = "Versión inicial de prueba\nMantén pulsado PROBAR SONIDO para escuchar.\nConecta tu teclado mediante adaptador USB OTG."
            setTextColor(Color.LTGRAY)
            textSize = 13f
            gravity = Gravity.CENTER
            setPadding(8, 24, 8, 8)
        }
        layout.addView(title)
        layout.addView(status)
        layout.addView(midi)
        layout.addView(note)
        layout.addView(info)
        setContentView(layout)
    }

    private fun scanMidi() {
        val devices = midiManager.devices
        if (devices.isEmpty()) {
            status.text = "No se detectó dispositivo MIDI. Revisa el cable OTG y vuelve a intentar."
            return
        }
        val names = devices.joinToString { it.properties.getString(MidiDeviceInfo.PROPERTY_NAME) ?: "MIDI USB" }
        status.text = "Dispositivo(s) detectado(s): $names. Próximo paso: abrir puerto MIDI."
        // The first prototype detects MIDI devices. Port opening and MIDI event routing
        // will be added in the next development stage.
    }

    override fun onDestroy() {
        midiDevice?.close()
        synth?.stop()
        super.onDestroy()
    }
}

private class SimpleSynth {
    private val running = AtomicBoolean(false)
    @Volatile private var frequency = 0.0
    @Volatile private var amplitude = 0.0
    private var phase = 0.0
    private var track: AudioTrack? = null

    fun start() {
        val sampleRate = 44100
        val min = AudioTrack.getMinBufferSize(
            sampleRate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT
        )
        track = AudioTrack(
            AudioManager.STREAM_MUSIC, sampleRate,
            AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT,
            maxOf(min, 4096), AudioTrack.MODE_STREAM
        )
        running.set(true)
        track?.play()
        Thread {
            val buffer = ShortArray(1024)
            while (running.get()) {
                for (i in buffer.indices) {
                    val target = amplitude
                    val sample = sin(phase) * target
                    phase += 2.0 * PI * frequency / sampleRate
                    if (phase > 2.0 * PI) phase -= 2.0 * PI
                    buffer[i] = (sample * 12000.0).toInt().toShort()
                }
                track?.write(buffer, 0, buffer.size)
            }
        }.start()
    }

    fun noteOn(note: Int, velocity: Int) {
        frequency = 440.0 * Math.pow(2.0, (note - 69) / 12.0)
        amplitude = (velocity.coerceIn(0, 127) / 127.0) * 0.7
    }

    fun noteOff(note: Int) { amplitude = 0.0 }

    fun stop() {
        running.set(false)
        track?.pause()
        track?.flush()
        track?.release()
        track = null
    }
}
